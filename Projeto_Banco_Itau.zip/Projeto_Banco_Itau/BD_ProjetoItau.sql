/* CRIANDO BASE DE DADOS */
create database projeto;

/* CONECTANDO A BASE DE DADOS */
use projeto;

/* CRIANDO AS TABELAS DO BANCO DADOS */
create table banco(
	idBanco integer auto_increment,
	nomeBanco varchar(50) not null unique,
	primary key(idBanco)
);

create table agencia(
	idAgencia integer auto_increment,
	numeroAgencia integer not null unique,
	enderecoAgencia varchar(255) not null,
	id_Banco integer not null,
	primary key(idAgencia)
);

create table conta(
	idConta integer auto_increment,
	numeroConta varchar(100) not null unique,
	digitoConta char(2) not null,
	saldoConta decimal(10,2) not null,
	dac integer not null,
	id_Agencia integer not null,	
	primary key(idConta)
);

create table movimento(
	idMovimento integer auto_increment,
	tipoMovimento varchar(100) not null,
	dataMovimento date not null,
	valorMovimento decimal(10,2) not null,
	id_Conta integer not null,
	primary key(idMovimento)
);

create table correntista(
	idCorrentista integer auto_increment,
	nomeCorrentista varchar(100) not null,
	cpfCorrentista varchar(15) not null unique,
	sexoCorrentista enum('M','F') not null,
	primary key(idCorrentista)
);

create table conta_correntista(
	id_Correntista integer,
	id_Conta integer,
	primary key(id_Conta, id_Correntista)
);

/* ADICIONANDO FOREIGN KEYS */
alter table agencia
add constraint fk_banco_agencia
foreign key(id_Banco)
references banco(idBanco);

alter table conta
add constraint fk_agencia_conta
foreign key(id_Agencia)
references agencia(idAgencia);

alter table movimento
add constraint fk_conta_movimento
foreign key(id_Conta)
references conta(idConta);

alter table conta_correntista
add constraint fk_conta
foreign key(id_Conta)
references conta(idConta);

alter table conta_correntista
add constraint fk_correntista
foreign key(id_Correntista)
references correntista(idCorrentista);

/* ADICIONANDO VALORES AO BANCO DE DADOS */
insert into banco
values	(1,"Banco do Brasil S.A."),
		(341,"Banco Itaú S.A."),
		(33,"Banco Santander (Brasil) S.A."),
		(237,"Banco Bradesco S.A."),
		(104,"Caixa Econômica Federal");
insert into agencia
values 	(1,2873,"PARQUE ANHANGABAU NUM 226 - CENTRO",104),
		(2,4054,"AVENIDA GUAPIRA NUM 2440 - JACANA",104),
		(3,3317,"AVENIDA WASHINGTON LUIS NUM 6971 - VILA CONGONHAS",104),
		(4,2484,"AVENIDA AGUA FRIA NUM 1105 - AGUA FRIA",1),
		(5,3289,"AVENIDA AGUIA DE HAIA NUM 1586/1600",1),
		(6,2036,"RUA FERNANDO FALCAO NUM 59/75 - VILA CLAUDIA",341),
		(7,3287,"AVENIDA AMADOR BUENO DA VEIGA NUM 1161 - PENHA DE FRANCA",341),
		(8,4788,"AVENIDA DOUTOR GENTIL DE MOURA NUM 56/90 - IPIRANGA",33),
		(9,4990,"ESTRADA DAS TAIPAS NUM 355 - JARDIM SAO JOAO",237),
		(10,3365,"RUA AZEVEDO SOARES NUM 2753 - VILA GOMES CARDIM",33),
		(11,3039,"RUA ALVARES PENTEADO NUM 195 - CENTRO",237),
		(12,2924,"RUA EMILIA MARENGO NUM 731 - VILA REGENTE FEIJO",237),
		(13,4007,"AVENIDA RIO DAS PEDRAS NUM 1907 - JARDIM ARICANDUVA",33);

insert into conta
values	(1,"000001","2",20200,123654,1),
		(2,"000002","4",9500,321654,10),
		(3,"000003","6",150,147258,5);

insert into movimento
values	(1,"deposito","2020-05-23",200.00,1), 
		(2,"deposito","2019-08-05",9500.00,2), 
		(3,"saque","2020-05-20",500.00,3);

insert into correntista
values	(1,"Edney","123.123.123-00","M"),
		(2,"Isabela","123.123.123-11","F"),
		(3,"Wagner Oliveira","123.123.123-01","M");

insert into conta_correntista
values	(1,2),
		(2,2),
		(3,3);	


/*	QUERIES TESTE FUNCIONAMENTO DO BD  */
select 
	b.idBanco as '#',
	b.nomeBanco as 'Banco',
	ag.numeroAgencia as 'Agencia',
    ag.enderecoAgencia as 'Endereco Agencia'
from banco b
inner join agencia ag
on b.idBanco = ag.id_Banco
where idBanco = 033;

select 
	ct.numeroConta as 'Num Conta',
	ct.saldoConta as 'Saldo',
	mv.tipoMovimento as 'Tipo',
	mv.dataMovimento as 'Data'
from conta ct
inner join movimento mv
on ct.idConta = mv.id_Conta;


select 
	corr.nomeCorrentista as 'Nome',
    corr.cpfCorrentista as 'CPF',
    ct.numeroConta as 'Conta',
    ct.saldoConta as 'Saldo'
from conta_correntista cc
inner join correntista corr
on corr.idCorrentista = cc.id_Correntista
inner join conta ct
on ct.idConta = cc.id_Conta;	

/* 1 - Cadastro Conta */
insert into conta values (idConta,"numeroConta","digito",saldoConta,dac,idAgencia);
insert into correntista values(idCorrentista,"nomeTitular","cpf","sexo");
insert into conta_correntista values(idCorrentista,idConta);

/* 2 - Consultar Conta */
select 
	corr.nomeCorrentista as 'Titular',
	corr.cpfCorrentista as 'CPF',
	corr.sexoCorrentista as 'Sexo',
	cta.numeroConta as 'Conta',
    cta.digitoConta as 'Digito',
	cta.saldoConta as 'Saldo'
from conta_correntista cc
inner join correntista corr
on corr.idCorrentista = cc.id_Correntista
inner join conta cta
on cta.idConta = cc.id_Conta
where cta.numeroConta = '000002';

/* 3 - Operações */

/* 3.1 - Credito */
